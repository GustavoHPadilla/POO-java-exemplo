import java.util.Scanner;


public class Banco {

    Scanner in = new Scanner(System.in);
    Usuario usuario = new Usuario();
    

    public Banco() {
        try {
            tela_escolha();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public void tela_escolha() throws InterruptedException{

        int erro = 0, opcao = 0, opcao2 = 0;


        //Menu de opções para o user.
        System.out.print("\033[H\033[2J");
        System.out.flush();

        System.out.println("\n\n");

        System.out.println("┌────────────────────────────────┐");
        System.out.println("│ Escolha uma das opções abaixo. │");
        System.out.println("└────────────────────────────────┘");
        System.out.println("┌──────────────────────────┬─────┐");
        System.out.println("│ Opção                    │ Num │");
        System.out.println("├──────────────────────────┼─────┤");
        System.out.println("│ Sacar                    │  1  │");
        System.out.println("│ Depositar                │  2  │");
        System.out.println("│ Extrato                  │  3  │");
        System.out.println("├──────────────────────────┼─────┤");
        System.out.println("│ Sair                     │  0  │");
        System.out.println("└──────────────────────────┴─────┘\n");

        System.out.print("│ Opção: ");
        opcao = in.nextInt();

        switch(opcao){
            case 0: System.exit(0);
            case 1: break;
            case 2: break;
            case 3: break;
            default: erro = 1;
        }


        //Tratamento de erro.
        if(erro == 1){
            System.out.print("\033[H\033[2J");
            System.out.flush();

            System.out.println("\n\n");
            System.out.println("┌───────────────────────────────┐");
            System.out.println("│ Gostaria de tentar novamente? │");
            System.out.println("└───────────────────────────────┘");
            System.out.println("┌─────────────────────────┬─────┐");
            System.out.println("│ Opção                   │ Num │");
            System.out.println("├─────────────────────────┼─────┤");
            System.out.println("│ Sim                     │  1  │");
            System.out.println("│ Não                     │  2  │");
            System.out.println("└─────────────────────────┴─────┘\n");
            System.out.println("│ Opção: ");
            opcao2 = in.nextInt();

            if(opcao2 == 1){
                erro = 0;
                tela_escolha();
            }
            else {
                System.exit(0);
            }

        }

    }
}
