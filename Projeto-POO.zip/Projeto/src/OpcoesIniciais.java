
import java.util.Scanner;
import java.lang.Thread;


public class OpcoesIniciais {
    
    Scanner in = new Scanner(System.in);
    Usuario usuario = new Usuario();


    static int id = 0;


    public OpcoesIniciais() {
        try {
            tela_escolha();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public void tela_escolha() throws InterruptedException{

        int erro = 0, opcao = 0, opcao2 = 0;


        //Menu de opções para o user.
        System.out.print("\033[H\033[2J");
        System.out.flush();

        System.out.println("\n\n");

        System.out.println("┌────────────────────────────────┐");
        System.out.println("│ Escolha uma das opções abaixo. │");
        System.out.println("└────────────────────────────────┘");
        System.out.println("┌──────────────────────────┬─────┐");
        System.out.println("│ Opção                    │ Num │");
        System.out.println("├──────────────────────────┼─────┤");
        System.out.println("│ Login                    │  1  │");
        System.out.println("│ Cadastro                 │  2  │");
        System.out.println("├──────────────────────────┼─────┤");
        System.out.println("│ Sair                     │  0  │");
        System.out.println("└──────────────────────────┴─────┘\n");

        System.out.print("│ Opção: ");
        opcao = in.nextInt();

        switch(opcao){
            case 0: System.exit(0);
            case 1: login(); break;
            case 2: cadastro(); break;
            default: erro = 1;
        }


        //Tratamento de erro.
        if(erro == 1){
            System.out.print("\033[H\033[2J");
            System.out.flush();

            System.out.println("\n\n");
            System.out.println("┌───────────────────────────────┐");
            System.out.println("│ Gostaria de tentar novamente? │");
            System.out.println("└───────────────────────────────┘");
            System.out.println("┌─────────────────────────┬─────┐");
            System.out.println("│ Opção                   │ Num │");
            System.out.println("├─────────────────────────┼─────┤");
            System.out.println("│ Sim                     │  1  │");
            System.out.println("│ Não                     │  2  │");
            System.out.println("└─────────────────────────┴─────┘\n");
            System.out.println("│ Opção: ");
            opcao2 = in.nextInt();

            if(opcao2 == 1){
                erro = 0;
                tela_escolha();
            }
            else {
                System.exit(0);
            }

        }

    }


    private void login() throws InterruptedException{

        int opcao = 0;

        //Tratamento de erro
        if(usuario.getNome() == null || usuario.getSenha() == null){

            System.out.print("\033[H\033[2J");
            System.out.flush();

            System.out.println("\n\n");
            System.out.println("┌──────────────────────────────────────────────────────────┐");
            System.out.println("│ Ops, não há dados cadastrados! Gostaria de cadastra-los? │");
            System.out.println("└──────────────────────────────────────────────────────────┘");
            System.out.println("┌────────────────────────────────────────────────────┬─────┐");
            System.out.println("│ Opção                                              │ Num │");
            System.out.println("├────────────────────────────────────────────────────┼─────┤");
            System.out.println("│ Sim                                                │  1  │");
            System.out.println("│ Não                                                │  2  │");
            System.out.println("└────────────────────────────────────────────────────┴─────┘\n");
            System.out.print("│ Opção: ");
            opcao = in.nextInt();

            if(opcao == 1){
                try {
                    cadastro();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            else {
                System.exit(0);
            }

        }


        //Inserindo valores nas devidas variaveis
        System.out.print("\033[H\033[2J");
        System.out.flush();

        System.out.println("\n\n");
        System.out.println("┌─────────────────────┐");
        System.out.println("│ Realização de login │");
        System.out.println("└─────────────────────┘\n");

        System.out.print("│ Nome: ");
        String nomeA = in.next();

        System.out.print("│\n│ Senha: ");
        String senhaA = in.next();


        //Puxando nome e senha real.
        String nomeReal = usuario.getNome();
        String senhaReal = usuario.getSenha();

        
        //Verificação
        if(nomeA == nomeReal){
            Banco banco = new Banco();
        }
        else {
            System.out.print("\033[H\033[2J");
            System.out.flush();

            System.out.println("" + nomeA + "+" + nomeReal + "");
            System.out.println("" + senhaA + "+" + senhaReal + "");

            System.out.println("\n\n");
            System.out.println("┌─────────────────────────────────────────────────────┐");
            System.out.println("│ Ops, dados inválidos! Gostaria de tentar novamente? │");
            System.out.println("└─────────────────────────────────────────────────────┘");
            System.out.println("┌───────────────────────────────────────────────┬─────┐");
            System.out.println("│ Opção                                         │ Num │");
            System.out.println("├───────────────────────────────────────────────┼─────┤");
            System.out.println("│ Sim                                           │  1  │");
            System.out.println("│ Não                                           │  2  │");
            System.out.println("└───────────────────────────────────────────────┴─────┘\n");
            System.out.print("│ Opção: ");
            opcao = in.nextInt();

            if(opcao == 1){
                login();
            }
            else {
                System.exit(0);
            }
        }

    }


    private void cadastro() throws InterruptedException {

        int opcao = 0;

        if(usuario.getNome() == null || usuario.getSenha() == null){
            usuario.setNome(null);
            usuario.setSenha(null);
        }

        //Inserindo valores nas devidas variaveis
        System.out.print("\033[H\033[2J");
        System.out.flush();

        System.out.println("\n\n");
        System.out.println("┌────────────────────────┐");
        System.out.println("│ Realização de cadastro │");
        System.out.println("└────────────────────────┘\n");

        System.out.print("│ Nome: ");
        usuario.setNome(in.next());

        System.out.print("│\n│ Senha: ");
        usuario.setSenha(in.next());

        //Tratamento de erro
        if(usuario.getNome() == "" || usuario.getSenha() == ""){

            System.out.print("\033[H\033[2J");
            System.out.flush();

            System.out.println("\n\n");
            System.out.println("┌────────────────────────────────────┐");
            System.out.println("│ Ops! Gostaria de tentar novamente? │");
            System.out.println("└────────────────────────────────────┘");
            System.out.println("┌──────────────────────────────┬─────┐");
            System.out.println("│ Opção                        │ Num │");
            System.out.println("├──────────────────────────────┼─────┤");
            System.out.println("│ Sim                          │  1  │");
            System.out.println("│ Não                          │  2  │");
            System.out.println("└──────────────────────────────┴─────┘\n");
            System.out.println("│ Opção: ");
            opcao = in.nextInt();

            if(opcao == 1){
                usuario.setNome(null);
                usuario.setSenha(null);

                cadastro();
            }
            else {
                System.exit(0);
            }

        }
        else {
            System.out.print("\033[H\033[2J");
            System.out.flush();
    
            System.out.println("\n\n");
            System.out.println("┌─────────────────────────────────┐");
            System.out.println("│ Cadastro concluido com sucesso! │");
            System.out.println("└─────────────────────────────────┘\n");
    
            Thread.sleep(2000);
    
            tela_escolha();
        }
    }



}
